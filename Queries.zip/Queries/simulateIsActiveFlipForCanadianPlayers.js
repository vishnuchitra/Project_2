import { MongoClient } from 'mongodb';

// Define MongoDB connection URL and details
const url = 'mongodb://localhost:27017/';
const dbName = 'Speedrun';
const collectionName = 'Player';

async function simulateIsActiveFlipForCanadianPlayers() {
  const client = new MongoClient(url);

  try {
    // Connect to MongoDB
    await client.connect();
    console.log('Connected correctly to server');

    // Access the specified database and collection
    const db = client.db(dbName);
    const collection = db.collection(collectionName);

    // Define the aggregation pipeline
    const agg = [
      {
        '$match': {
          'country': 'Canada'
        }
      }, {
        '$addFields': {
          'isActive': { '$not': '$isActive' } // Simulates flipping the 'isActive' field
        }
      }
    ];

    // Execute the aggregation pipeline
    const result = await collection.aggregate(agg).toArray();
    console.log('Aggregation result:', result);

  } catch (err) {
    // Handle any errors
    console.error('An error occurred:', err);
  } finally {
    // Close the MongoDB client
    await client.close();
    console.log('Connection closed');
  }
}

// Invoke the function to run the aggregation
simulateIsActiveFlipForCanadianPlayers();
