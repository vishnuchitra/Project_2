import { MongoClient } from 'mongodb';

const url = 'mongodb://localhost:27017/';
const dbName = 'Speedrun'; 
const collectionName = 'Game'; 

async function findGamesByDeveloper() {
  const client = new MongoClient(url);
  
  try {
    await client.connect();
    console.log('Connected correctly to server');
    
    const db = client.db(dbName);
    const collection = db.collection(collectionName);
    
    // Aggregation pipeline to match documents by a specific developer
    const agg = [
      {
        '$match': {
          'developer': 'Schroeder, Schuppe and Hamill'
        }
      }
    ];
    
    const result = await collection.aggregate(agg).toArray();
    console.log('Aggregation result:', result);
    
  } catch (err) {
    console.error('An error occurred:', err);
  } finally {
    await client.close();
    console.log('Connection closed');
  }
}

findGamesByDeveloper();