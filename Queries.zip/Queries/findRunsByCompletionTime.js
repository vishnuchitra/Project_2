import { MongoClient } from 'mongodb';

// Define MongoDB connection string and database/collection names
const url = 'mongodb://localhost:27017/';
const dbName = 'Speedrun';
const collectionName = 'Run';

async function findRunsByCompletionTime() {
  const client = new MongoClient(url);
  
  try {
    // Connect to the MongoDB client
    await client.connect();
    console.log('Connected correctly to server');
    
    // Access the specific database and collection
    const db = client.db(dbName);
    const collection = db.collection(collectionName);
    
    // Define the aggregation pipeline
    const agg = [
      {
        '$match': {
          'completionTime': { '$lt': 802615697 } // Modify this value as needed
        }
      }
    ];
    
    // Perform the aggregation query
    const result = await collection.aggregate(agg).toArray();
    console.log('Aggregation result:', result);
    
  } catch (err) {
    // Handle any errors that occur during the connection or aggregation
    console.error('An error occurred:', err);
  } finally {
    // Ensure the client is closed after the operation completes
    await client.close();
    console.log('Connection closed');
  }
}

// Execute the function to find runs by completion time
findRunsByCompletionTime();
