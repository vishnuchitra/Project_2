import { MongoClient } from 'mongodb';

// Define the MongoDB connection URL and database/collection details
const url = 'mongodb://localhost:27017/';
const dbName = 'Speedrun';
const collectionName = 'Category';

async function findCategoryByName() {
  const client = new MongoClient(url);

  try {
    // Establish a connection to the MongoDB server
    await client.connect();
    console.log('Connected correctly to server');

    // Access the specified database and collection
    const db = client.db(dbName);
    const collection = db.collection(collectionName);

    // Define the aggregation pipeline to match documents by name
    const agg = [
      {
        '$match': {
          'name': 'Any%' // Match documents where name is 'Any%'
        }
      }
    ];

    // Execute the aggregation query and convert the cursor to an array
    const result = await collection.aggregate(agg).toArray();
    console.log('Aggregation result:', result);

  } catch (err) {
    // Handle any errors that might occur during the operation
    console.error('An error occurred:', err);
  } finally {
    // Ensure that the MongoDB client connection is closed
    await client.close();
    console.log('Connection closed');
  }
}

// Invoke the function to perform the aggregation operation
findCategoryByName();
