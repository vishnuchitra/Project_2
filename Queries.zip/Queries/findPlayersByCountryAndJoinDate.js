import { MongoClient } from 'mongodb';

// MongoDB connection details
const url = 'mongodb://localhost:27017/';
const dbName = 'Speedrun';
const collectionName = 'Player';

async function findPlayersByCountryAndJoinDate() {
  const client = new MongoClient(url);

  try {
    // Establish connection to MongoDB
    await client.connect();
    console.log('Connected correctly to server');

    // Access the database and collection
    const db = client.db(dbName);
    const collection = db.collection(collectionName);

    // Define the aggregation pipeline
    const agg = [
      {
        '$match': {
          '$expr': {
            '$and': [
              {
                '$or': [
                  { '$eq': ['$country', 'USA'] }, 
                  { '$eq': ['$country', 'India'] }
                ]
              }, 
              {
                '$gt': ['$joinDate', new Date('Wed, 01 Jan 2020 00:00:00 GMT')]
              }
            ]
          }
        }
      }
    ];

    // Execute the aggregation query
    const result = await collection.aggregate(agg).toArray();
    console.log('Aggregation result:', result);

  } catch (err) {
    console.error('An error occurred:', err);
  } finally {
    await client.close();
    console.log('Connection closed');
  }
}

// Invoke the function to run the aggregation query
findPlayersByCountryAndJoinDate();
