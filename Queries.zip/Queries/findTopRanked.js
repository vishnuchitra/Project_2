import { MongoClient } from 'mongodb';

// MongoDB connection string and database details
const url = 'mongodb://localhost:27017/';
const dbName = 'Speedrun';
const collectionName = 'Ranking';

async function findTopRanked() {
  const client = new MongoClient(url);

  try {
    // Connect to the MongoDB client
    await client.connect();
    console.log('Connected correctly to server');

    // Access the specific database and collection
    const db = client.db(dbName);
    const collection = db.collection(collectionName);

    // Define the aggregation pipeline
    const agg = [
      {
        '$match': {
          'rank': 1 // Match documents where the rank is 1
        }
      }
    ];

    // Execute the aggregation query
    const result = await collection.aggregate(agg).toArray();
    console.log('Aggregation result:', result);

  } catch (err) {
    // Handle any errors that occur during the operation
    console.error('An error occurred:', err);
  } finally {
    // Ensure the client is closed once operations are complete
    await client.close();
    console.log('Connection closed');
  }
}

// Execute the function to perform the aggregation
findTopRanked();
