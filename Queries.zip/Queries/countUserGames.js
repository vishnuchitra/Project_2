import { MongoClient } from 'mongodb';

// MongoDB connection URL and database configuration
const url = 'mongodb://localhost:27017/';
const dbName = 'Speedrun';
const collectionName = 'Plays';

async function countUserGames() {
  const client = new MongoClient(url);

  try {
    // Connect to the MongoDB client
    await client.connect();
    console.log('Connected correctly to server');

    // Access the specific database and collection
    const db = client.db(dbName);
    const collection = db.collection(collectionName);

    // Define the aggregation pipeline to count games for a specific user
    const agg = [
      {
        '$match': { 'username': 'mprout0' } // Match documents with this username
      }, {
        '$count': 'totalGames' // Count the matching documents
      }
    ];

    // Perform the aggregation query
    const result = await collection.aggregate(agg).toArray();
    console.log('Aggregation result:', result);

  } catch (err) {
    // Handle any errors that occur during the connection or aggregation
    console.error('An error occurred:', err);
  } finally {
    // Ensure the client is closed after the operation completes
    await client.close();
    console.log('Connection closed');
  }
}

// Execute the function to count games for the user 'mprout0'
countUserGames();
