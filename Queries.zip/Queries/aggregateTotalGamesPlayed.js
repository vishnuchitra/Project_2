import { MongoClient } from 'mongodb';

// MongoDB connection string and database configuration
const url = 'mongodb://localhost:27017/';
const dbName = 'Speedrun';
const collectionName = 'Plays';

async function aggregateTotalGamesPlayed() {
  const client = new MongoClient(url);

  try {
    // Connect to the MongoDB client
    await client.connect();
    console.log('Connected correctly to server');

    // Access the specific database and collection
    const db = client.db(dbName);
    const collection = db.collection(collectionName);

    // Define the aggregation pipeline
    const agg = [
      {
        '$group': {
          '_id': '$username',
          'totalGamesPlayed': { '$sum': 1 }
        }
      }, {
        '$sort': { 'totalGamesPlayed': -1 }
      }
    ];

    // Execute the aggregation query
    const result = await collection.aggregate(agg).toArray();
    console.log('Aggregation result:', result);

  } catch (err) {
    // Handle any errors that might occur
    console.error('An error occurred:', err);
  } finally {
    // Ensure the MongoDB client is closed when done
    await client.close();
    console.log('Connection closed');
  }
}

// Call the function to execute the aggregation
aggregateTotalGamesPlayed();
